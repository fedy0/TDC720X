# TDC720X Time-to-Digital Converter (TDC)
Arduino library for the TDC720X Time-to-Digital Converter (TDC) Series (TDC7200 & TDC7201) from Texax Instruments Inc. which measure time between events on its START and STOP pins
